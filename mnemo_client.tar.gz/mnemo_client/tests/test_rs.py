import itertools
import random
import unittest

from mnemo import gf, rs


def corrupt(code, erase, err, rng):
    w = list(code)
    for i in erase:
        w[i] = None
    for i in err:
        w[i] = (w[i] ^ rng.randrange(1, gf.Q))
    return w


class TestRS(unittest.TestCase):
    def test_systematic(self):
        rng = random.Random(3)
        for _ in range(100):
            m = [rng.randrange(gf.Q) for _ in range(4)]
            self.assertEqual(rs.encode(m, 8)[:4], m)

    def test_every_pattern_within_radius_rs84(self):
        """All erasure/error position patterns with 2e+s <= 4, several random messages each."""
        rng = random.Random(4)
        n, k = 8, 4
        patterns = 0
        for s in range(n - k + 1):
            for e in range((n - k - s) // 2 + 1):
                for erase in itertools.combinations(range(n), s):
                    rest = [i for i in range(n) if i not in erase]
                    for err in itertools.combinations(rest, e):
                        for _ in range(3):
                            m = [rng.randrange(gf.Q) for _ in range(k)]
                            got = rs.decode(corrupt(rs.encode(m, n), erase, err, rng), k)
                            self.assertEqual(got, m, (erase, err))
                        patterns += 1
        # s=0: 1+8+28; s=1: 8+8*7; s=2: 28+28*6; s=3: 56; s=4: 70
        self.assertEqual(patterns, 423)

    def test_other_codes(self):
        rng = random.Random(5)
        for n, k in ((10, 5), (12, 4), (16, 4), (6, 4)):
            for _ in range(300):
                m = [rng.randrange(gf.Q) for _ in range(k)]
                s = rng.randrange(n - k + 1)
                e = rng.randrange((n - k - s) // 2 + 1)
                pos = rng.sample(range(n), s + e)
                got = rs.decode(corrupt(rs.encode(m, n), pos[:s], pos[s:], rng), k)
                self.assertEqual(got, m, (n, k, s, e))

    def test_beyond_radius_never_unjustified(self):
        """Past the radius the decoder returns None or a codeword within radius of the input."""
        rng = random.Random(6)
        n, k = 8, 4
        outcomes = {"none": 0, "other": 0, "same": 0}
        for _ in range(3000):
            m = [rng.randrange(gf.Q) for _ in range(k)]
            while True:
                s, e = rng.randrange(n + 1), rng.randrange(n + 1)
                if s + e <= n and 2 * e + s > n - k:
                    break
            pos = rng.sample(range(n), s + e)
            w = corrupt(rs.encode(m, n), pos[:s], pos[s:], rng)
            got = rs.decode(w, k)
            if got is None:
                outcomes["none"] += 1
                continue
            c = rs.encode(got, n)
            wrong = sum(1 for x, y in zip(w, c) if x is not None and x != y)
            erased = sum(x is None for x in w)
            self.assertLessEqual(2 * wrong + erased, n - k)
            outcomes["same" if got == m else "other"] += 1
        self.assertGreater(outcomes["none"], 0)

    def test_too_many_erasures(self):
        self.assertIsNone(rs.decode([None] * 5 + [1, 2, 3], 4))


if __name__ == "__main__":
    unittest.main()
