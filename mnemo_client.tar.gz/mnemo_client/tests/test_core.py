import copy
import json
import random
import unittest

from mnemo import core, kdf
from mnemo.codebook import Codebook

P = kdf.KDFParams(memory_kib=64, time_cost=1, lanes=1, chain_length=3)
CB = Codebook.load()


def fresh(seed=7, data=b"the E2EE root secret"):
    words, rec = core.enroll(data, P, cb=CB, rng=random.Random(seed))
    return words, rec, data


def other_word(w, rng):
    while True:
        x = CB.words[rng.randrange(1024)]
        if x != w:
            return x


class TestCodebook(unittest.TestCase):
    def test_properties(self):
        w = CB.words
        self.assertEqual(len({x[:4] for x in w}), 1024)
        self.assertTrue(all(4 <= len(x) <= 9 for x in w))
        self.assertEqual(CB.sha256, "9893db26da3c79d85d2a26adeb6dd85942ce052e947b27f9f0a3b12c0ae4f83a")

    def test_gate(self):
        w = CB.words[100]
        self.assertEqual(CB.gate(w.upper() + " "), (100, None))
        self.assertEqual(CB.gate(w[:4])[0], 100)          # unique 4-letter prefix
        self.assertEqual(CB.gate("?"), (None, None))
        self.assertEqual(CB.gate(w[:-1] + ("a" if w[-1] != "a" else "b")), (None, w))  # one typo


class TestEndToEnd(unittest.TestCase):
    def test_exact(self):
        words, rec, data = fresh()
        self.assertEqual(len(words), 8)
        self.assertEqual(core.recover(words, rec, CB), data)

    def test_forgot_one_misremembered_one(self):
        words, rec, data = fresh(8)
        rng = random.Random(1)
        t = list(words)
        t[3] = "?"
        t[6] = other_word(t[6], rng)
        self.assertEqual(core.recover(t, rec, CB), data)

    def test_four_forgotten_or_two_wrong(self):
        words, rec, data = fresh(9)
        rng = random.Random(2)
        t = list(words)
        for i in (0, 2, 5, 7):
            t[i] = "?"
        self.assertEqual(core.recover(t, rec, CB), data)
        t = list(words)
        for i in (1, 4):
            t[i] = other_word(t[i], rng)
        self.assertEqual(core.recover(t, rec, CB), data)

    def test_beyond_radius_fails_safely(self):
        words, rec, data = fresh(10)
        rng = random.Random(3)
        fails = 0
        for trial in range(20):
            t = list(words)
            for i in rng.sample(range(8), 3):
                t[i] = other_word(t[i], rng)
            try:
                out = core.recover(t, rec, CB)
                self.assertEqual(out, data)     # only possible if it decoded to the truth
            except core.RecoveryError:
                fails += 1
        self.assertGreater(fails, 0)

    def test_tampering_rejected(self):
        words, rec, data = fresh(11)
        for mutate in (lambda r: r.__setitem__("ct", r["ct"][:-4] + ("AAAA" if r["ct"][-4:] != "AAAA" else "BBBB")),
                       lambda r: r["params"].__setitem__("n", 9),
                       lambda r: r["params"]["kdf"].__setitem__("chain_length", 2),
                       lambda r: r["params"].__setitem__("codebook_sha256", "0" * 64)):
            r2 = copy.deepcopy(rec)
            mutate(r2)
            with self.assertRaises((core.RecoveryError, ValueError)):
                core.recover(words if r2["params"]["n"] == 8 else words + ["?"], r2, CB)

    def test_record_is_public_json(self):
        _, rec, data = fresh(12)
        s = json.dumps(rec)
        self.assertNotIn(data.decode(), s)
        self.assertEqual(set(rec), {"format", "version", "params", "salt", "nonce", "ct"})


if __name__ == "__main__":
    unittest.main()
