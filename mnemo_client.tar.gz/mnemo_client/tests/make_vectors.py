"""Regenerate tests/vectors.json (known-answer tests). Run once; the test compares against it."""
import json
import os

from mnemo import core, kdf, rs
from mnemo.codebook import Codebook

HERE = os.path.dirname(os.path.abspath(__file__))


def vectors():
    cb = Codebook.load()
    out = []
    for i, (msg, data) in enumerate((([0, 1, 2, 3], b"mnemo test vector 1"),
                                      ([1023, 512, 7, 999], b""),
                                      ([123, 456, 789, 1010], bytes(range(64))))):
        p = kdf.KDFParams(memory_kib=64 << i, time_cost=1 + i, lanes=1 + i, chain_length=2 + i)
        salt, nonce = bytes([i]) * 16, bytes([0x80 + i]) * 12
        words, rec = core.enroll(data, p, cb=cb, secret=(msg, salt, nonce))
        key = kdf.derive(core.pack_symbols(msg), salt, p)
        out.append({"msg": msg, "codeword": rs.encode(msg, 8), "words": words, "data_hex": data.hex(),
                    "key_hex": key.hex(), "record": rec})
    return out


if __name__ == "__main__":
    with open(os.path.join(HERE, "vectors.json"), "w") as f:
        json.dump(vectors(), f, indent=1)
    print("wrote tests/vectors.json")
