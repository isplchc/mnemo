import unittest

from mnemo import kdf

P = kdf.KDFParams(memory_kib=64, time_cost=1, lanes=1, chain_length=5)


class TestKDF(unittest.TestCase):
    def test_resume_matches_full_run(self):
        m, salt = b"\x01\x02\x03\x04\x05", b"s" * 16
        states = {}
        full = kdf.derive(m, salt, P, on_step=lambda i, s, t: states.__setitem__(i, s))
        self.assertEqual(sorted(states), [1, 2, 3, 4, 5])
        for i in range(1, 5):
            self.assertEqual(kdf.derive(m, salt, P, start=i, state=states[i]), full)

    def test_inputs_separate(self):
        m, salt = b"\x01\x02\x03\x04\x05", b"s" * 16
        k0 = kdf.derive(m, salt, P)
        self.assertNotEqual(k0, kdf.derive(b"\x01\x02\x03\x04\x04", salt, P))
        self.assertNotEqual(k0, kdf.derive(m, b"t" * 16, P))
        self.assertNotEqual(k0, kdf.derive(m, salt, kdf.KDFParams(64, 1, 1, 4)))
        self.assertEqual(len(k0), 32)

    def test_reference_profile(self):
        r = kdf.REFERENCE
        self.assertEqual((r.memory_kib, r.time_cost, r.lanes, r.chain_length), (1 << 20, 4, 4, 137_142))


if __name__ == "__main__":
    unittest.main()
