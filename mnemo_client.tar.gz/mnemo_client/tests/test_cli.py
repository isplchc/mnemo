import os
import shutil
import subprocess
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TMP = os.path.join(ROOT, "tests", "_tmp")


def run(*args, inp=None):
    return subprocess.run([sys.executable, "-m", "mnemo", *args], cwd=ROOT, input=inp,
                          capture_output=True, text=True)


class TestCLI(unittest.TestCase):
    def setUp(self):
        shutil.rmtree(TMP, ignore_errors=True)
        os.makedirs(TMP)

    def tearDown(self):
        shutil.rmtree(TMP, ignore_errors=True)

    def test_enroll_recover(self):
        data, rec, out, st = (os.path.join(TMP, x) for x in ("data.bin", "rec.json", "out.bin", "state"))
        with open(data, "wb") as f:
            f.write(b"secret payload")
        r = run("enroll", "--data", data, "--record", rec, "--profile", "demo", "--state", st)
        self.assertEqual(r.returncode, 0, r.stderr)
        lines = r.stdout.splitlines()
        i = len(lines) - 1 - lines[::-1].index("Your Mnemo words (memorize all of them, in order; do not store them):")
        words = [l.split(". ", 1)[1] for l in lines[i + 2:i + 10]]
        self.assertEqual(len(words), 8)
        words[2], words[5] = "?", words[5][:4]          # one forgotten, one typed by prefix
        r = run("recover", "--record", rec, "--out", out, "--words", " ".join(words), "--yes", "--state", st)
        self.assertEqual(r.returncode, 0, r.stderr)
        with open(out, "rb") as f:
            self.assertEqual(f.read(), b"secret payload")
        self.assertFalse(os.listdir(st))               # checkpoints removed


    def test_resume_from_checkpoint(self):
        """A recovery interrupted after step 2 resumes there and gives the same result."""
        import json
        import random
        from mnemo import core, kdf
        from mnemo.checkpoint import Checkpoint
        words, rec = core.enroll(b"resume me", kdf.DEMO, rng=random.Random(5))
        recp, out, st = (os.path.join(TMP, x) for x in ("rec.json", "out.bin", "state"))
        with open(recp, "w") as f:
            json.dump(rec, f)
        msg, _, _ = core.decode_words(words, rec)
        salt = core._unb64(rec["salt"])
        states = {}
        kdf.derive(core.pack_symbols(msg), salt, kdf.DEMO, on_step=lambda i, s, t: states.__setitem__(i, s))
        Checkpoint(os.path.join(st, "recover.json")).save(
            {"kind": "recover", "record": core.record_id(rec), "msg": msg, "i": 2,
             "state": states[2].hex()}, force=True)
        self.assertEqual(oct(os.stat(os.path.join(st, "recover.json")).st_mode & 0o777), "0o600")
        r = run("recover", "--record", recp, "--out", out, "--yes", "--state", st)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("Resuming recovery at step 2", r.stdout)
        with open(out, "rb") as f:
            self.assertEqual(f.read(), b"resume me")


if __name__ == "__main__":
    unittest.main()
