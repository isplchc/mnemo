"""Known-answer tests: the same inputs must give the same codewords, keys, and records everywhere."""
import json
import os
import unittest

from mnemo import core
from mnemo.codebook import Codebook
from tests.make_vectors import vectors

HERE = os.path.dirname(os.path.abspath(__file__))


class TestVectors(unittest.TestCase):
    def test_known_answers(self):
        with open(os.path.join(HERE, "vectors.json")) as f:
            expected = json.load(f)
        self.assertEqual(vectors(), expected)

    def test_vectors_recover(self):
        cb = Codebook.load()
        with open(os.path.join(HERE, "vectors.json")) as f:
            for v in json.load(f):
                self.assertEqual(core.recover(v["words"], v["record"], cb).hex(), v["data_hex"])


if __name__ == "__main__":
    unittest.main()
