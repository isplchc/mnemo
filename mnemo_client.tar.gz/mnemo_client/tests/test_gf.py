import random
import unittest

from mnemo import gf


class TestGF(unittest.TestCase):
    def test_primitive(self):
        self.assertEqual(sorted(gf.EXP[:gf.ORDER]), list(range(1, gf.Q)))

    def test_field_axioms(self):
        rng = random.Random(1)
        for _ in range(2000):
            a, b, c = (rng.randrange(gf.Q) for _ in range(3))
            self.assertEqual(gf.mul(a, b), gf.mul(b, a))
            self.assertEqual(gf.mul(a, b ^ c), gf.mul(a, b) ^ gf.mul(a, c))
            self.assertEqual(gf.mul(gf.mul(a, b), c), gf.mul(a, gf.mul(b, c)))
            if a:
                self.assertEqual(gf.mul(a, gf.inv(a)), 1)

    def test_poly(self):
        rng = random.Random(2)
        for _ in range(200):
            p = [rng.randrange(gf.Q) for _ in range(rng.randrange(1, 7))]
            d = [rng.randrange(gf.Q) for _ in range(rng.randrange(1, 4))] + [rng.randrange(1, gf.Q)]
            q, r = gf.poly_divmod(gf.poly_mul(p, d), d)
            self.assertEqual(q, gf.poly_trim(p))
            self.assertEqual(r, [])
            xs = [gf.alpha(i) for i in range(len(p))]
            ys = [gf.poly_eval(p, x) for x in xs]
            self.assertEqual(gf.poly_trim(gf.interpolate(xs, ys)), gf.poly_trim(p))


if __name__ == "__main__":
    unittest.main()
