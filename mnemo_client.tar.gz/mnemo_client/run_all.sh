#!/usr/bin/env bash
# One command: isolated venv, unit + known-answer tests, a demo walkthrough, and a calibration of
# the reference KDF on this machine. Everything stays inside this directory.
set -euo pipefail
cd "$(dirname "$0")"
HERE="$(pwd)"
export PIP_CACHE_DIR="$HERE/.cache/pip" TMPDIR="$HERE/.tmp" PYTHONDONTWRITEBYTECODE=1
mkdir -p "$TMPDIR" results
PY="${PYTHON:-python3}"
"$PY" -c 'import sys; assert sys.version_info >= (3, 9), "Python >= 3.9 required"'
[ -x .venv/bin/python ] || "$PY" -m venv .venv
.venv/bin/python -m pip install -q --upgrade pip
.venv/bin/python -m pip install -q -r requirements.txt
V=.venv/bin/python
{
  echo "== environment"; $V -c 'import platform,sys; print(platform.platform()); print(sys.version.split()[0])'
  $V - <<'PY'
import os, platform, subprocess
cpu = None
try:
    if platform.system() == "Darwin":
        cpu = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True).stdout.strip()
    else:
        cpu = next(l.split(":", 1)[1].strip() for l in open("/proc/cpuinfo") if l.startswith("model name"))
except Exception:
    pass
print("cpu:", cpu or platform.processor() or "unknown", "| logical cores:", os.cpu_count())
PY
  $V -m pip freeze | grep -iE 'argon2|cryptography'
  echo; echo "== tests"; $V -m unittest discover -s tests -t . -v 2>&1
  echo; echo "== demo (demo profile: seconds of work, NO security)"
  printf 'Mnemo demo payload\n' > .tmp/demo_data.txt
  rm -f .tmp/demo_record.json .tmp/demo_out.txt
  $V -m mnemo enroll --data .tmp/demo_data.txt --record .tmp/demo_record.json --profile demo --state .tmp/state | tee .tmp/enroll.log
  WORDS=$(grep -E '^   [1-8]\. ' .tmp/enroll.log | tail -8 | awk '{print $2}' | tr '\n' ' ')
  set -- $WORDS; WRONG=garden; [ "$5" = garden ] && WRONG=copper
  RECALL="$1 $2 ? $4 $WRONG $6 ${7:0:4} $8"
  echo "recall typed (3rd forgotten, 5th misremembered as '$WRONG', 7th by prefix): $RECALL"
  $V -m mnemo recover --record .tmp/demo_record.json --out .tmp/demo_out.txt --words "$RECALL" --yes --state .tmp/state
  cmp .tmp/demo_data.txt .tmp/demo_out.txt && echo "demo: recovered payload matches"
  echo; echo "== calibration of the reference profile (1 GiB, t=4, p=4) on this machine"
  $V -m mnemo calibrate --profile reference
} 2>&1 | tee results/selftest.txt
rm -rf .tmp
echo; echo "Done. Report: results/selftest.txt"
