"""Mnemo reference client: trustless, forget-tolerant recovery of a secret from assigned words.

Instance of the generic compiler Comp[(E,D), F, AEAD] with E,D = systematic RS[8,4] over GF(2^10)
(one 1024-word codebook symbol per word), F = a chain of Argon2id evaluations in final-call form,
AEAD = AES-256-GCM. See README.md.
"""
__version__ = "1.0.0"
