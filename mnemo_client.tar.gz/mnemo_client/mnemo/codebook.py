"""The public codebook: 1024 words, one GF(2^10) symbol each, and the leak-free input gate.

The gate looks only at the public codebook, never at the secret:
  exact word                 -> its symbol
  unique 4+-letter prefix    -> that word's symbol (every codebook word has a unique 4-letter prefix)
  '?', '', '-'               -> erasure (the user knows they forgot)
  anything else              -> erasure, plus a suggestion if exactly one word is one edit away
"""
import hashlib
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_PATH = os.path.join(HERE, "codebook_v1.txt")
FORGOT = {"?", "", "-"}


class Codebook:
    def __init__(self, words):
        if len(words) != 1024 or len(set(words)) != 1024:
            raise ValueError("codebook must have 1024 distinct words")
        if any(not w.isascii() or not w.isalpha() or not w.islower() for w in words):
            raise ValueError("codebook words must be lowercase ASCII letters")
        self.words = list(words)
        self.index = {w: i for i, w in enumerate(words)}
        self.prefix = {}
        for w in words:
            self.prefix.setdefault(w[:4], []).append(w)
        self.sha256 = hashlib.sha256(("\n".join(words) + "\n").encode()).hexdigest()

    @staticmethod
    def load(path=DEFAULT_PATH):
        with open(path, encoding="ascii") as f:
            return Codebook(f.read().split())

    def word(self, sym):
        return self.words[sym]

    def gate(self, token):
        """-> (symbol or None, suggestion or None)."""
        t = token.strip().lower()
        if t in FORGOT:
            return None, None
        if t in self.index:
            return self.index[t], None
        if len(t) >= 4:
            hits = [w for w in self.prefix.get(t[:4], []) if w.startswith(t)]
            if len(hits) == 1:
                return self.index[hits[0]], None
        near = [w for w in self.words if _within_one(t, w)]
        return None, (near[0] if len(near) == 1 else None)


def _within_one(a, b):
    """Levenshtein distance <= 1."""
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la > lb:
        a, b, la, lb = b, a, lb, la
    i = 0
    while i < la and a[i] == b[i]:
        i += 1
    return a[i + 1:] == b[i + 1:] if la == lb else a[i:] == b[i + 1:]
