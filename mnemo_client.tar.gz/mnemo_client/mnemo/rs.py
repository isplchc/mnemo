"""Systematic Reed-Solomon RS[n,k] over GF(2^10) with errors-and-erasures decoding.

Evaluation code: a codeword is (f(a_0), ..., f(a_{n-1})) for a polynomial f of degree < k, with
a_i = alpha^i. Systematic: f is the interpolant of the message at a_0..a_{k-1}, so the first k
codeword symbols are the message. Minimum distance n-k+1 (MDS).

decode() returns the message whenever 2e + s <= n - k (e wrong symbols, s erasures). Otherwise it
returns None, or -- unavoidably, when the recall is closer to another codeword -- a different
message; the AEAD tag then rejects it. Every returned codeword is checked to lie within the
decoding radius of the input, so the decoder never returns a codeword it could not justify.
"""
from . import gf


def points(n):
    if not 1 <= n <= gf.ORDER:
        raise ValueError("n must be in [1, 1023]")
    return [gf.alpha(i) for i in range(n)]


def encode(msg, n):
    k = len(msg)
    if not 1 <= k <= n:
        raise ValueError("need 1 <= k <= n")
    if any(not 0 <= m < gf.Q for m in msg):
        raise ValueError("symbols must be in [0, 1024)")
    a = points(n)
    f = gf.interpolate(a[:k], msg)
    return [gf.poly_eval(f, x) for x in a]


def decode(word, k):
    """word: list of n symbols, None marking an erasure. Returns the k message symbols or None."""
    n = len(word)
    a = points(n)
    idx = [i for i, y in enumerate(word) if y is not None]
    if any(not 0 <= word[i] < gf.Q for i in idx):
        raise ValueError("symbols must be in [0, 1024)")
    m = len(idx)                     # unerased positions
    if m < k:
        return None
    e = (m - k) // 2                 # error-correcting capacity after erasures
    # Berlekamp-Welch on the unerased positions: find E (monic, deg e) and Q (deg < e+k) with
    # Q(a_i) = y_i E(a_i). Unknowns: E_0..E_{e-1}, Q_0..Q_{e+k-1}.
    A, b = [], []
    for i in idx:
        x, y = a[i], word[i]
        row = [gf.mul(y, gf.power(x, j)) for j in range(e)]          # y * E_j x^j  (moved to LHS)
        row += [gf.power(x, j) for j in range(e + k)]                 # Q_j x^j
        A.append(row)
        b.append(gf.mul(y, gf.power(x, e)))                           # y * x^e (monic term)
    sol = gf.solve(A, b)
    if sol is None:
        return None
    E = sol[:e] + [1]
    Qp = sol[e:]
    f, rem = gf.poly_divmod(Qp, E)
    if rem or len(f) > k:
        return None
    code = [gf.poly_eval(f, x) for x in a]
    wrong = sum(code[i] != word[i] for i in idx)
    if 2 * wrong + (n - m) > n - k:
        return None
    return code[:k]
