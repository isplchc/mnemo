"""Arithmetic in GF(2^10) = GF(2)[x] / (x^10 + x^3 + 1).

x^10 + x^3 + 1 is primitive, so alpha = x generates the multiplicative group of order 1023
(checked at import time). Elements are ints in [0, 1024).
"""
M = 10
Q = 1 << M          # 1024
POLY = 0x409        # x^10 + x^3 + 1
ORDER = Q - 1       # 1023

EXP = [0] * (2 * ORDER)
LOG = [-1] * Q
_v = 1
for _i in range(ORDER):
    EXP[_i] = _v
    if LOG[_v] != -1:
        raise AssertionError("POLY is not primitive")
    LOG[_v] = _i
    _v <<= 1
    if _v & Q:
        _v ^= POLY
if _v != 1:
    raise AssertionError("POLY is not primitive")
for _i in range(ORDER, 2 * ORDER):
    EXP[_i] = EXP[_i - ORDER]


def add(a, b):
    return a ^ b


def mul(a, b):
    if a == 0 or b == 0:
        return 0
    return EXP[LOG[a] + LOG[b]]


def inv(a):
    if a == 0:
        raise ZeroDivisionError("0 has no inverse in GF(2^10)")
    return EXP[ORDER - LOG[a]]


def div(a, b):
    return mul(a, inv(b))


def power(a, e):
    if e == 0:
        return 1
    if a == 0:
        return 0
    return EXP[(LOG[a] * e) % ORDER]


def alpha(i):
    """alpha^i, the i-th evaluation point."""
    return EXP[i % ORDER]


# ---- polynomials: coefficient lists, lowest degree first ----

def poly_trim(p):
    p = list(p)
    while p and p[-1] == 0:
        p.pop()
    return p


def poly_eval(p, x):
    acc = 0
    for c in reversed(p):
        acc = mul(acc, x) ^ c
    return acc


def poly_mul(p, q):
    if not p or not q:
        return []
    out = [0] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        if a:
            for j, b in enumerate(q):
                out[i + j] ^= mul(a, b)
    return poly_trim(out)


def poly_divmod(num, den):
    num, den = poly_trim(num), poly_trim(den)
    if not den:
        raise ZeroDivisionError("division by the zero polynomial")
    if len(num) < len(den):
        return [], num
    num = list(num)
    q = [0] * (len(num) - len(den) + 1)
    lead_inv = inv(den[-1])
    for i in range(len(num) - len(den), -1, -1):
        c = mul(num[i + len(den) - 1], lead_inv)
        q[i] = c
        if c:
            for j, d in enumerate(den):
                num[i + j] ^= mul(c, d)
    return poly_trim(q), poly_trim(num[: len(den) - 1])


def interpolate(xs, ys):
    """Unique polynomial of degree < len(xs) through the points (Lagrange)."""
    out = [0] * len(xs)
    for i, (xi, yi) in enumerate(zip(xs, ys)):
        if yi == 0:
            continue
        basis, denom = [1], 1
        for j, xj in enumerate(xs):
            if j != i:
                basis = poly_mul(basis, [xj, 1])          # (x - xj) = (x + xj) in char 2
                denom = mul(denom, xi ^ xj)
        scale = mul(yi, inv(denom))
        for d, c in enumerate(basis):
            out[d] ^= mul(c, scale)
    return out


def solve(A, b):
    """One solution of A x = b over GF(2^10) (free variables set to 0), or None if inconsistent."""
    rows, cols = len(A), len(A[0]) if A else 0
    M_ = [list(r) + [v] for r, v in zip(A, b)]
    piv_cols, r = [], 0
    for c in range(cols):
        p = next((i for i in range(r, rows) if M_[i][c]), None)
        if p is None:
            continue
        M_[r], M_[p] = M_[p], M_[r]
        f = inv(M_[r][c])
        M_[r] = [mul(v, f) for v in M_[r]]
        for i in range(rows):
            if i != r and M_[i][c]:
                g = M_[i][c]
                M_[i] = [vi ^ mul(g, vr) for vi, vr in zip(M_[i], M_[r])]
        piv_cols.append(c)
        r += 1
        if r == rows:
            break
    for i in range(r, rows):
        if M_[i][cols]:
            return None
    x = [0] * cols
    for i, c in enumerate(piv_cols):
        x[c] = M_[i][cols]
    return x
