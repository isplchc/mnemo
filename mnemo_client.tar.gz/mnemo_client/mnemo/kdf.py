"""The day-scale costly function F_T in final-call form F(x) = O_out(x, Phi(x)).

x = m_bytes || salt.  Phi is a chain of L Argon2id evaluations:
    s_0 = m_bytes
    s_i = Argon2id(password = s_{i-1} || u32be(i), salt = salt, m, t, p, 32-byte tag),  i = 1..L
and the key is
    kappa = SHA-256("mnemo-v1/key" || u32be(len x) || x || s_L).
The 32-byte chain state s_i is all a checkpoint needs; resuming at step i gives the same kappa.
"""
import hashlib
import struct
import time
from dataclasses import dataclass, asdict

from argon2.low_level import Type, hash_secret_raw, ARGON2_VERSION

DOMAIN_KEY = b"mnemo-v1/key"


@dataclass(frozen=True)
class KDFParams:
    memory_kib: int        # Argon2id memory per evaluation
    time_cost: int         # Argon2id passes
    lanes: int             # Argon2id parallelism
    chain_length: int      # L
    version: int = ARGON2_VERSION   # 0x13

    def to_dict(self):
        return asdict(self)

    @staticmethod
    def from_dict(d):
        p = KDFParams(int(d["memory_kib"]), int(d["time_cost"]), int(d["lanes"]),
                      int(d["chain_length"]), int(d.get("version", ARGON2_VERSION)))
        p.validate()
        return p

    def validate(self):
        if self.version != ARGON2_VERSION:
            raise ValueError("unsupported Argon2 version")
        if self.lanes < 1 or self.time_cost < 1 or self.chain_length < 1:
            raise ValueError("lanes, time_cost, chain_length must be >= 1")
        if self.memory_kib < 8 * self.lanes:
            raise ValueError("memory_kib must be >= 8 * lanes")


# Reference profile: 1 GiB, t=4, p=4, L = 24 h / 0.63 s on an Intel Core Ultra 7 270K Plus.
REFERENCE = KDFParams(memory_kib=1 << 20, time_cost=4, lanes=4, chain_length=137_142)
# Demo profile: seconds, NOT secure; for tests and the walkthrough only.
DEMO = KDFParams(memory_kib=8 << 10, time_cost=1, lanes=1, chain_length=4)


def argon2id(password, salt, p):
    return hash_secret_raw(secret=password, salt=salt, time_cost=p.time_cost,
                           memory_cost=p.memory_kib, parallelism=p.lanes, hash_len=32,
                           type=Type.ID, version=p.version)


def step(state, i, salt, p):
    return argon2id(state + struct.pack(">I", i), salt, p)


def finalize(m_bytes, salt, s_last):
    x = m_bytes + salt
    return hashlib.sha256(DOMAIN_KEY + struct.pack(">I", len(x)) + x + s_last).digest()


def derive(m_bytes, salt, p, start=0, state=None, on_step=None):
    """Run the chain from step `start` (state = s_start; s_0 = m_bytes if start == 0).
    on_step(i, s_i, elapsed) is called after every step and may checkpoint."""
    p.validate()
    s = m_bytes if start == 0 else state
    if s is None:
        raise ValueError("resuming requires the saved state")
    t0 = time.monotonic()
    for i in range(start + 1, p.chain_length + 1):
        s = step(s, i, salt, p)
        if on_step:
            on_step(i, s, time.monotonic() - t0)
    return finalize(m_bytes, salt, s)


def time_one(p, reps=2):
    """Seconds per Argon2id evaluation at p on this device (median of reps)."""
    ts = []
    for r in range(reps):
        t0 = time.perf_counter()
        argon2id(b"calibration" + bytes([r]), b"mnemo-calibrate!", p)
        ts.append(time.perf_counter() - t0)
    ts.sort()
    return ts[len(ts) // 2]
