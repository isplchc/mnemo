"""Mnemo Enroll / Recover (Algorithm 2 of the paper) and the public record format.

Record (JSON, public; may be stored anywhere):
  {"format": "mnemo-record", "version": 1,
   "params": {"n", "k", "field": "GF(2^10)/x^10+x^3+1", "points": "alpha^0..alpha^(n-1)",
              "codebook_sha256", "kdf": {memory_kib, time_cost, lanes, chain_length, version}},
   "salt": b64(16 bytes), "nonce": b64(12 bytes), "ct": b64(AES-256-GCM ciphertext || tag)}
The AES-GCM associated data is the canonical JSON of {format, version, params, salt}, so any change
to the public parameters makes decryption fail instead of silently changing the scheme.
"""
import base64
import hashlib
import json
import os
import secrets

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from . import gf, rs
from .codebook import Codebook
from .kdf import KDFParams, derive

FORMAT, VERSION = "mnemo-record", 1
FIELD, POINTS = "GF(2^10)/x^10+x^3+1", "alpha^0..alpha^(n-1)"
SALT_LEN, NONCE_LEN = 16, 12


class RecoveryError(Exception):
    pass


def pack_symbols(sym):
    """k 10-bit symbols -> ceil(10k/8) bytes, big-endian."""
    v = 0
    for s in sym:
        v = (v << gf.M) | s
    nbits = gf.M * len(sym)
    nbytes = (nbits + 7) // 8
    return (v << (8 * nbytes - nbits)).to_bytes(nbytes, "big")


def _b64(b):
    return base64.b64encode(b).decode()


def _unb64(s):
    return base64.b64decode(s.encode(), validate=True)


def _aad(rec):
    head = {k: rec[k] for k in ("format", "version", "params", "salt")}
    return json.dumps(head, sort_keys=True, separators=(",", ":")).encode()


def record_id(rec):
    return hashlib.sha256(json.dumps(rec, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def make_params(n, k, cb, kdf):
    if not 1 <= k < n <= gf.ORDER:
        raise ValueError("need 1 <= k < n <= 1023")
    return {"n": n, "k": k, "field": FIELD, "points": POINTS,
            "codebook_sha256": cb.sha256, "kdf": kdf.to_dict()}


def new_secret(k=4, rng=None):
    """Sample the secret (k uniform symbols), the salt, and the nonce."""
    rng = rng or secrets.SystemRandom()
    msg = [rng.randrange(gf.Q) for _ in range(k)]
    salt = bytes(rng.getrandbits(8) for _ in range(SALT_LEN))
    nonce = bytes(rng.getrandbits(8) for _ in range(NONCE_LEN))
    return msg, salt, nonce


def words_for(msg, n, cb=None):
    cb = cb or Codebook.load()
    return [cb.word(s) for s in rs.encode(msg, n)]


def enroll(data, kdf, n=8, k=4, cb=None, rng=None, secret=None, start=0, state=None, on_step=None):
    """-> (words, record). The words go to the user's memory only; the record is public.
    `secret` = (msg, salt, nonce) from new_secret() lets a checkpointed enrollment resume."""
    cb = cb or Codebook.load()
    params = make_params(n, k, cb, kdf)
    msg, salt, nonce = secret or new_secret(k, rng)
    if len(msg) != k:
        raise ValueError("secret has the wrong length")
    rec = {"format": FORMAT, "version": VERSION, "params": params, "salt": _b64(salt)}
    key = derive(pack_symbols(msg), salt, kdf, start=start, state=state, on_step=on_step)
    rec["nonce"] = _b64(nonce)
    rec["ct"] = _b64(AESGCM(key).encrypt(nonce, data, _aad(rec)))
    return words_for(msg, n, cb), rec


def check_record(rec, cb):
    if rec.get("format") != FORMAT or rec.get("version") != VERSION:
        raise RecoveryError("not a mnemo-record v1")
    p = rec["params"]
    if p.get("field") != FIELD or p.get("points") != POINTS:
        raise RecoveryError("unsupported code")
    if p.get("codebook_sha256") != cb.sha256:
        raise RecoveryError("this record was made with a different codebook")
    kdf = KDFParams.from_dict(p["kdf"])
    salt = _unb64(rec["salt"])
    if len(salt) != SALT_LEN or len(_unb64(rec["nonce"])) != NONCE_LEN:
        raise RecoveryError("malformed record")
    return int(p["n"]), int(p["k"]), kdf, salt


def decode_words(tokens, rec, cb=None):
    """Free step (no KDF): gate each token, then errors-and-erasures decode.
    -> (message symbols or None, symbols-with-erasures, suggestions)."""
    cb = cb or Codebook.load()
    n, k, _, _ = check_record(rec, cb)
    if len(tokens) != n:
        raise RecoveryError(f"expected {n} words, got {len(tokens)}")
    gated = [cb.gate(t) for t in tokens]
    syms = [g[0] for g in gated]
    return rs.decode(syms, k), syms, [g[1] for g in gated]


def recover_with_message(msg, rec, cb=None, start=0, state=None, on_step=None):
    """The day-scale step: derive the key for a decoded message and open the record.
    Raises RecoveryError if the tag does not verify (wrong words beyond the code's reach)."""
    cb = cb or Codebook.load()
    _, _, kdf, salt = check_record(rec, cb)
    key = derive(pack_symbols(msg), salt, kdf, start=start, state=state, on_step=on_step)
    try:
        return AESGCM(key).decrypt(_unb64(rec["nonce"]), _unb64(rec["ct"]), _aad(rec))
    except Exception:
        raise RecoveryError("decryption failed: the decoded words are not the enrolled ones") from None


def recover(tokens, rec, cb=None, **kw):
    msg, _, _ = decode_words(tokens, rec, cb)
    if msg is None:
        raise RecoveryError("too many forgotten or wrong words to decode")
    return recover_with_message(msg, rec, cb, **kw)
