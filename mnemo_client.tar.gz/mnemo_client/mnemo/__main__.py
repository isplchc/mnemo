"""Command-line client.

  python -m mnemo enroll    --data FILE --record RECORD.json [--profile reference|demo]
  python -m mnemo recover   --record RECORD.json --out FILE [--words "w1 w2 ? ..."] [--dry-run]
  python -m mnemo calibrate [--profile reference] [--hours 24]

Enrollment and recovery each run the day-scale chain once and resume from a checkpoint after an
interruption (rerun the same command). State lives in ./state/ next to this package unless --state
is given; it holds secret material and is deleted when the run finishes.
"""
import argparse
import json
import os
import sys

from . import core, kdf
from .checkpoint import Checkpoint
from .codebook import Codebook

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROFILES = {"reference": kdf.REFERENCE, "demo": kdf.DEMO}


def _hms(s):
    s = int(s)
    return f"{s // 3600}h{(s % 3600) // 60:02d}m{s % 60:02d}s"


def _progress(ck, payload, total, start):
    def on_step(i, s, elapsed):
        payload["i"], payload["state"] = i, s.hex()
        ck.save(payload, force=(i == total))
        done = i - start
        if done and (done % max(1, total // 200) == 0 or i == total):
            eta = elapsed / done * (total - i)
            print(f"\r  step {i:,}/{total:,}  elapsed {_hms(elapsed)}  remaining ~{_hms(eta)}   ",
                  end="", flush=True)
    return on_step


def _show_words(words):
    print("\nYour Mnemo words (memorize all of them, in order; do not store them):\n")
    for i, w in enumerate(words, 1):
        print(f"   {i}. {w}")
    print()


def cmd_enroll(a):
    cb = Codebook.load()
    params = PROFILES[a.profile]
    if a.profile != "reference":
        print("WARNING: demo profile -- seconds of work, no security. Use it only to try the client.")
    if os.path.exists(a.record) and not a.force:
        sys.exit(f"{a.record} exists; pass --force to overwrite")
    with open(a.data, "rb") as f:
        data = f.read()
    ck = Checkpoint(os.path.join(a.state, "enroll.json"))
    saved = ck.load()
    if saved and saved.get("kind") == "enroll" and saved.get("kdf") == params.to_dict() \
            and saved.get("n") == a.n and saved.get("k") == a.k:
        msg, salt, nonce = saved["msg"], bytes.fromhex(saved["salt"]), bytes.fromhex(saved["nonce"])
        start, state = saved["i"], (bytes.fromhex(saved["state"]) if saved["i"] else None)
        print(f"Resuming enrollment at step {start:,} of {params.chain_length:,}.")
    else:
        msg, salt, nonce = core.new_secret(a.k)
        start, state = 0, None
    payload = {"kind": "enroll", "kdf": params.to_dict(), "n": a.n, "k": a.k, "msg": msg,
               "salt": salt.hex(), "nonce": nonce.hex(), "i": start,
               "state": state.hex() if state else ""}
    ck.save(payload, force=True)
    _show_words(core.words_for(msg, a.n, cb))
    print("Deriving the key (the same work recovery will need once). Keep rehearsing meanwhile.")
    words, rec = core.enroll(data, params, a.n, a.k, cb, secret=(msg, salt, nonce), start=start,
                             state=state, on_step=_progress(ck, payload, params.chain_length, start))
    with open(a.record, "w") as f:
        json.dump(rec, f, indent=1)
    ck.clear()
    print(f"\n\nWrote the public record to {a.record}. It may be stored anywhere; keep copies.")
    _show_words(words)


def _ask_words(n, cb):
    toks = []
    for i in range(1, n + 1):
        while True:
            t = input(f"word {i} of {n} (? if forgotten): ")
            sym, sugg = cb.gate(t)
            if sym is not None or t.strip() in ("?", "", "-"):
                toks.append(t)
                break
            if sugg and input(f"  not a codebook word; did you mean '{sugg}'? [y/N] ").lower() == "y":
                toks.append(sugg)
                break
            if input("  not a codebook word; mark as forgotten? [Y/n] ").lower() != "n":
                toks.append("?")
                break
    return toks


def cmd_recover(a):
    cb = Codebook.load()
    with open(a.record) as f:
        rec = json.load(f)
    n, k, params, _ = core.check_record(rec, cb)
    rid = core.record_id(rec)
    ck = Checkpoint(os.path.join(a.state, "recover.json"))
    saved = ck.load()
    if saved and saved.get("kind") == "recover" and saved.get("record") == rid:
        msg, start = saved["msg"], saved["i"]
        state = bytes.fromhex(saved["state"]) if start else None
        print(f"Resuming recovery at step {start:,} of {params.chain_length:,}.")
    else:
        toks = a.words.split() if a.words else _ask_words(n, cb)
        msg, syms, _ = core.decode_words(toks, rec, cb)
        s = sum(x is None for x in syms)
        if msg is None:
            sys.exit(f"Cannot decode: {s} word(s) unrecognized and too many others disagree. "
                     f"Up to {n - k} forgotten words, or {(n - k) // 2} wrong ones, can be fixed.")
        fixed = sum(1 for x, y in zip(syms, core.rs.encode(msg, n)) if x is not None and x != y)
        print(f"Decoded: {s} forgotten and {fixed} corrected word(s).")
        if a.dry_run:
            return
        t1 = kdf.time_one(params, reps=1)
        print(f"This device needs ~{_hms(t1 * params.chain_length)} "
              f"({params.chain_length:,} steps at {t1:.2f} s). The run can be interrupted and resumed.")
        if not a.yes and input("Start? [y/N] ").lower() != "y":
            return
        start, state = 0, None
    if os.path.exists(a.out) and not a.force:
        sys.exit(f"{a.out} exists; pass --force to overwrite")
    payload = {"kind": "recover", "record": rid, "msg": msg, "i": start,
               "state": state.hex() if state else ""}
    ck.save(payload, force=True)
    try:
        data = core.recover_with_message(msg, rec, cb, start=start, state=state,
                                         on_step=_progress(ck, payload, params.chain_length, start))
    except core.RecoveryError as e:
        ck.clear()
        sys.exit(f"\n{e}")
    fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    ck.clear()
    print(f"\n\nRecovered {len(data)} bytes to {a.out}.")


def cmd_calibrate(a):
    p = PROFILES[a.profile]
    t = kdf.time_one(p, reps=3)
    L = max(1, round(a.hours * 3600 / t))
    print(f"one Argon2id evaluation ({p.memory_kib // 1024} MiB, t={p.time_cost}, p={p.lanes}): {t:.3f} s")
    print(f"chain length for {a.hours:g} h on this device: L = {L:,}")
    print(f"the {a.profile} profile's L = {p.chain_length:,} takes ~{_hms(t * p.chain_length)} here")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="mnemo", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("enroll")
    e.add_argument("--data", required=True)
    e.add_argument("--record", required=True)
    e.add_argument("--profile", choices=PROFILES, default="reference")
    e.add_argument("--n", type=int, default=8)
    e.add_argument("--k", type=int, default=4)
    r = sub.add_parser("recover")
    r.add_argument("--record", required=True)
    r.add_argument("--out", required=True)
    r.add_argument("--words")
    r.add_argument("--dry-run", action="store_true", help="decode only; no key derivation")
    r.add_argument("--yes", action="store_true")
    for p_ in (e, r):
        p_.add_argument("--state", default=os.path.join(ROOT, "state"))
        p_.add_argument("--force", action="store_true")
    c = sub.add_parser("calibrate")
    c.add_argument("--profile", choices=PROFILES, default="reference")
    c.add_argument("--hours", type=float, default=24.0)
    a = ap.parse_args(argv)
    {"enroll": cmd_enroll, "recover": cmd_recover, "calibrate": cmd_calibrate}[a.cmd](a)


if __name__ == "__main__":
    main()
