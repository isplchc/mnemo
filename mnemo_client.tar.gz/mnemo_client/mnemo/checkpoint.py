"""Resumable chain state. A checkpoint holds the decoded secret and the chain state, so it is as
sensitive as the words themselves: it is written with mode 0600 and deleted when the run ends."""
import json
import os
import time


class Checkpoint:
    def __init__(self, path, every_s=30.0):
        self.path, self.every_s, self._last = path, every_s, 0.0

    def load(self):
        try:
            with open(self.path) as f:
                return json.load(f)
        except FileNotFoundError:
            return None

    def save(self, payload, force=False):
        now = time.monotonic()
        if not force and now - self._last < self.every_s:
            return
        self._last = now
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        tmp = self.path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(payload, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self.path)

    def clear(self):
        for p in (self.path, self.path + ".tmp"):
            try:
                os.remove(p)
            except FileNotFoundError:
                pass
