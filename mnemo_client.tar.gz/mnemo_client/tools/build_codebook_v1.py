#!/usr/bin/env python3
"""Build the Mnemo reference codebook v1 (1024 words, 10 bits/word), reusing experiment 7's pipeline.
Candidates: the EFF large diceware wordlist (7,776 words, vetted by the EFF for memorability and to
exclude offensive words; CC BY 3.0 US; file taken from the xkcdpass 1.19.9 sdist, xkcdpass/static/
eff-long, placed at data_eff/eff-long), intersected with the frequency-ordered SWOW pool
(nouns/adjectives/verbs, 4-9 letters). Greedy in frequency order, accepting w only if:
 (1) no SWOW association of strength >= THETA (R2, either direction) with an accepted word
     (association-free; experiment 7's unvetted list used 0.05, the vetted pool needs 0.15 for 1024);
 (2) its 4-letter prefix is new, so four letters identify the word;
 (3) Levenshtein distance >= 2 to every accepted word, so one typo never yields another valid word;
 (4) it is not an inflection of an accepted word or a plural of a pool word;
 (5) it does not end in -ing/-ed, is not very frequent (Zipf >= ZMAX), and is not on a hand list of
     names, brands, religious, medical, violent, and irregular-verb forms.
Prints the SWOW collision mass (substitutions that land on another codeword) against BIP39.
Run from c_experiments/ (needs data/ as in README): python3 build_codebook_v1.py"""
THETA = 0.15
POSSET = ("NOUN", "ADJ", "VERB")
ZMAX = 5.5   # drop the most frequent, least distinctive words (other, said, much, ...)
import sys
exec(compile(open("codebook_exp4b_assoc.py").read().split("\nout = []")[0], "exp4b", "exec"))

BAD2 = set("""nazi rape drug drugs bomb gun guns slave murder suicide penis vagina breast nude naked jesus allah
god gods church islam bible jew muslim christ cancer death corpse whore racist racism idiot killer victim
weapon slavery sexism prisoner disease divorce funeral disney iphone billy gang fraud terror abortion porn
disaster poverty anxiety disorder therapy virus penalty horror dementia autism obesity bully bullying
violence assault abuse torture prison jail genocide hostage cocaine heroin alcohol tobacco casino
facebook google twitter youtube netflix amazon apple microsoft android instagram ebay walmart nike
starbucks mcdonald iphone ipad xbox nintendo playstation pokemon batman superman marvel trump pope
buddhist trinity theology deity convent preacher pastor saint prayer sacred fascism opium ethanol
nicotine underage pregnant womb bladder deceased widow dictator evil hate lego python polo celtic morse
dude oops blah genocide racism sexist breeding kissing buddhism french
gave goes gone kept spent drove stole eaten written brought thank wish""".split())
from wordfreq import zipf_frequency
def lev(a, b):
    if abs(len(a) - len(b)) > 1:  # only care whether distance < 2
        return 2
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]
SUF = ("s", "es", "ed", "d", "ing", "er", "ers", "ly")
def inflected(a, b):
    for x, y in ((a, b), (b, a)):
        for suf in SUF:
            if x == y + suf or (y.endswith("e") and x == y[:-1] + suf):
                return True
    return False

EFF = set(open("data_eff/eff-long").read().split())
PS = set(pool)
def plural(w):
    return (w.endswith("s") and (w[:-1] in PS or (w.endswith("es") and w[:-2] in PS)
            or (w.endswith("ies") and w[:-3] + "y" in PS))) or w in {"people", "women", "children", "men", "feet", "teeth", "mice"}

chosen, banned, prefixes = [], set(), set()
for w in pool_c:
    if w not in EFF or pos.get(w) not in POSSET or not (4 <= len(w) <= 9) or w in BAD2 or w in banned or plural(w) \
            or w.endswith(("ing", "ed")) or zipf_frequency(w, "en") >= ZMAX:
        continue
    if w[:4] in prefixes:
        continue
    if any(lev(w, c) < 2 or inflected(w, c) for c in chosen):
        continue
    chosen.append(w); prefixes.add(w[:4])
    banned |= {r for r in assoc_set(w) if s(r, w) >= THETA}
    if len(chosen) == 1024:
        break
print("chosen", len(chosen))
if len(chosen) < 1024:
    sys.exit("pool exhausted")
open("codebook_v1.txt", "w").write("\n".join(chosen) + "\n")
def collision(code):
    """SWOW R1 mass of substitutions that land on another codeword (an undetectable error)."""
    cs = set(code); tot = hit = 0.0
    for w in code:
        A = R1.get(w)
        if not A: continue
        t = sum(A.values())
        for r, k in A.items():
            if r == w: continue
            tot += k / t; hit += (k / t) * (r in cs)
    return hit / tot
bip = open("data/bip39_english.txt").read().split()
print(f"collision mass: codebook_v1 {collision(chosen):.3f}, BIP39 {collision(bip):.3f}")
print(", ".join(chosen[:60]))
